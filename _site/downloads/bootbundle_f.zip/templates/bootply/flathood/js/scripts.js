
$(document).ready(function(){$('#sidebar').affix({
      offset: {
        top: 240
      }
});	
});